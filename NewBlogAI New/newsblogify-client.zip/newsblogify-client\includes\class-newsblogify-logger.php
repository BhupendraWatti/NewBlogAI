<?php
namespace NewsBlogify;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Logger {
    private static $instance = null;
    private $log_file;

    private function __construct() {
        $upload_dir = wp_upload_dir();
        $this->log_file = $upload_dir['basedir'] . '/newsblogify-logs.log';
    }

    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Log a message with a specific severity level.
     */
    public function log( $level, $message ) {
        $debug_mode = get_option( 'newsblogify_debug_mode', '0' );
        if ( 'debug' === $level && ! $debug_mode ) {
            return;
        }

        $timestamp = current_time( 'mysql' );
        $log_entry = sprintf( "[%s] [%s]: %s\n", $timestamp, strtoupper( $level ), $message );
        
        error_log( $log_entry, 3, $this->log_file );
    }

    /**
     * Get the absolute path to the log file.
     */
    public function get_log_file_path() {
        return $this->log_file;
    }

    /**
     * Retrieve the last N lines of the log.
     */
    public function get_logs( $lines = 100 ) {
        if ( ! file_exists( $this->log_file ) ) {
            return __( 'No log entries found.', 'newsblogify-client' );
        }

        $file = fopen( $this->log_file, 'r' );
        if ( ! $file ) {
            return __( 'Could not read log file.', 'newsblogify-client' );
        }

        $buffer = [];
        while ( ! feof( $file ) ) {
            $line = fgets( $file );
            if ( $line ) {
                $buffer[] = $line;
            }
        }
        fclose( $file );

        $output_lines = array_slice( $buffer, - $lines );
        return implode( '', $output_lines );
    }

    /**
     * Empty/clear the log file contents.
     */
    public function clear_logs() {
        if ( file_exists( $this->log_file ) ) {
            unlink( $this->log_file );
        }
        $this->log( 'info', 'Logs cleared by administrator.' );
    }
}
