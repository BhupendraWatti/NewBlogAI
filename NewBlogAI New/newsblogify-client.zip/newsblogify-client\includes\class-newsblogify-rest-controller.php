<?php
namespace NewsBlogify;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class REST_Controller {
    
    public static function register() {
        $instance = new self();
        add_action( 'rest_api_init', [ $instance, 'register_routes' ] );
    }

    /**
     * Register target endpoints under namespace ai-news/v1.
     */
    public function register_routes() {
        register_rest_route( 'ai-news/v1', '/ping', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'handle_ping' ],
            'permission_callback' => [ $this, 'verify_api_key' ],
        ] );

        register_rest_route( 'ai-news/v1', '/sync-data', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'handle_sync' ],
            'permission_callback' => [ $this, 'verify_api_key' ],
        ] );
    }

    /**
     * Authenticate incoming calls from Laravel using the stored API Token.
     */
    public function verify_api_key( \WP_REST_Request $request ) {
        $auth_header = $request->get_header( 'Authorization' );
        $token = '';

        if ( ! empty( $auth_header ) && preg_match( '/Bearer\s+(.*)$/i', $auth_header, $matches ) ) {
            $token = trim( $matches[1] );
        }

        if ( empty( $token ) ) {
            $token = $request->get_param( 'api_key' );
        }

        $stored_token = get_option( 'newsblogify_api_token', '' );

        if ( empty( $stored_token ) ) {
            return true;
        }

        if ( empty( $token ) || hash_equals( $stored_token, $token ) === false ) {
            return current_user_can( 'manage_options' );
        }

        return true;
    }

    /**
     * Callback for POST /wp-json/ai-news/v1/ping.
     */
    public function handle_ping( \WP_REST_Request $request ) {
        Logger::get_instance()->log( 'info', 'Received ping from Laravel backend.' );
        return new \WP_REST_Response( [
            'status'  => 'success',
            'version' => NEWSBLOGIFY_VERSION,
            'message' => 'Connection validated successfully!'
        ], 200 );
    }

    /**
     * Callback for POST /wp-json/ai-news/v1/sync-data.
     */
    public function handle_sync( \WP_REST_Request $request ) {
        $params = $request->get_json_params();
        Logger::get_instance()->log( 'info', 'Received synchronization data payload from Laravel.' );

        $selected_topics = isset( $params['selected_topics'] ) ? $params['selected_topics'] : [];
        $slot            = isset( $params['slot'] ) ? $params['slot'] : 'Daily';

        update_option( 'newsblogify_selected_topics', $selected_topics );
        update_option( 'newsblogify_posting_slot', $slot );
        update_option( 'newsblogify_last_sync_time', current_time( 'mysql' ) );

        Logger::get_instance()->log( 'info', sprintf( 'Sync success: configured slot %s with %d topic clusters.', $slot, count( $selected_topics ) ) );

        return new \WP_REST_Response( [
            'status'  => 'success',
            'message' => 'WordPress settings sync completed successfully.'
        ], 200 );
    }
}
