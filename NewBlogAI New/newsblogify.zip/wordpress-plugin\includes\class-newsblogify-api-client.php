<?php
namespace NewsBlogify;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class API_Client {
    private static $instance = null;

    private function __construct() {}

    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Send HTTP requests to Laravel Backend API.
     */
    public function request( $endpoint, $method = 'GET', $body = null, $args = [] ) {
        $backend_url = rtrim( get_option( 'newsblogify_backend_url', '' ), '/' );
        $api_token   = get_option( 'newsblogify_api_token', '' );

        if ( empty( $backend_url ) ) {
            return new \WP_Error( 'missing_url', 'Backend API URL is not configured.' );
        }

        $url = $backend_url . '/api/v1/' . ltrim( $endpoint, '/' );

        $headers = [
            'Accept'        => 'application/json',
            'Content-Type'  => 'application/json',
        ];

        // Authorize with Bearer Token if present
        if ( ! empty( $api_token ) ) {
            $headers['Authorization'] = 'Bearer ' . $api_token;
        }

        $request_args = wp_parse_args( $args, [
            'method'      => $method,
            'headers'     => $headers,
            'timeout'     => 30,
            'redirection' => 5,
            'httpversion' => '1.0',
            'blocking'    => true,
            'sslverify'   => false, // Disabled for local development compatibility
        ] );

        if ( null !== $body ) {
            $request_args['body'] = json_encode( $body );
        }

        Logger::get_instance()->log( 'debug', sprintf( 'Sending %s request to %s', $method, $url ) );

        $response = wp_remote_request( $url, $request_args );

        if ( is_wp_error( $response ) ) {
            Logger::get_instance()->log( 'error', sprintf( 'Request failed: %s', $response->get_error_message() ) );
            return $response;
        }

        $status_code = wp_remote_retrieve_response_code( $response );
        $response_body = wp_remote_retrieve_body( $response );

        Logger::get_instance()->log( 'debug', sprintf( 'Response status: %d', $status_code ) );

        if ( $status_code < 200 || $status_code >= 300 ) {
            $error_data = json_decode( $response_body, true );
            $error_msg = isset( $error_data['message'] ) ? $error_data['message'] : 'Server returned status ' . $status_code;
            Logger::get_instance()->log( 'error', sprintf( 'API Error status %d: %s', $status_code, $error_msg ) );
            return new \WP_Error( 'api_error', $error_msg, $status_code );
        }

        return json_decode( $response_body, true );
    }

    /**
     * Test connection to Backend.
     */
    public function test_connection( $backend_url, $api_token ) {
        $url = rtrim( $backend_url, '/' ) . '/api/v1/auth/me';

        $response = wp_remote_get( $url, [
            'headers' => [
                'Accept'        => 'application/json',
                'Authorization' => 'Bearer ' . $api_token,
            ],
            'sslverify' => false,
            'timeout'   => 15
        ] );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code( $response );
        if ( 200 !== $code ) {
            return new \WP_Error( 'unauthorized', 'Invalid credentials or API token. Status code: ' . $code );
        }

        return true;
    }

    /**
     * Register website configuration with Laravel backend.
     */
    public function register_site( $backend_url, $api_token, $site_name, $site_url, $admin_email ) {
        $url = rtrim( $backend_url, '/' ) . '/api/v1/sites';

        $payload = [
            'domain_url' => $site_url,
            'name'       => $site_name,
            'api_key'    => '', // The backend will use Application Passwords or sync via API
            'slot'       => 'Daily',
            'is_active'  => true,
        ];

        $response = wp_remote_post( $url, [
            'headers' => [
                'Accept'        => 'application/json',
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . $api_token,
            ],
            'body'      => json_encode( $payload ),
            'sslverify' => false,
            'timeout'   => 15
        ] );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = wp_remote_retrieve_body( $response );

        if ( $code < 200 || $code >= 300 ) {
            $err_data = json_decode( $body, true );
            $msg = isset( $err_data['message'] ) ? $err_data['message'] : 'Could not register website on backend (status ' . $code . ')';
            return new \WP_Error( 'registration_failed', $msg );
        }

        return json_decode( $body, true );
    }

    /**
     * Send heartbeat to Laravel backend reporting current states.
     */
    public function send_heartbeat() {
        $site_id = get_option( 'newsblogify_site_id', '' );
        if ( empty( $site_id ) ) {
            return;
        }

        $payload = [
            'plugin_version' => NEWSBLOGIFY_VERSION,
            'site_url'       => get_site_url(),
            'admin_email'    => get_option( 'admin_email' ),
            'timestamp'      => current_time( 'timestamp' ),
        ];

        $result = $this->request( '/sites/' . $site_id . '/heartbeat', 'POST', $payload );
        if ( ! is_wp_error( $result ) ) {
            update_option( 'newsblogify_last_sync_time', current_time( 'mysql' ) );
            Logger::get_instance()->log( 'info', 'Heartbeat sync completed successfully.' );
        }
    }
}
