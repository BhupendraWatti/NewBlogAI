<?php
namespace NewsBlogify;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Admin {
    private static $instance = null;

    private function __construct() {
        add_action( 'admin_menu', [ $this, 'register_admin_pages' ] );
        add_action( 'admin_init', [ $this, 'handle_form_submissions' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
    }

    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Enqueue CSS styling for dashboard and setup wizard.
     */
    public function enqueue_assets( $hook ) {
        if ( strpos( $hook, 'newsblogify' ) === false ) {
            return;
        }
        
        // Inline CSS styling for premium HSL dark-mode aesthetic matching Laravel OS Dashboard
        wp_register_style( 'newsblogify-admin-css', false );
        wp_enqueue_style( 'newsblogify-admin-css' );
        
        $custom_css = "
            .newsblogify-container {
                max-width: 1000px;
                margin: 20px auto;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
                color: #e2e8f0;
                background: #0f172a;
                border-radius: 16px;
                padding: 30px;
                border: 1px solid #1e293b;
                box-shadow: 0 10px 25px rgba(0,0,0,0.3);
            }
            .newsblogify-header {
                display: flex;
                align-items: center;
                justify-content: space-between;
                border-bottom: 1px solid #1e293b;
                padding-bottom: 20px;
                margin-bottom: 25px;
            }
            .newsblogify-title {
                font-size: 24px;
                font-weight: 800;
                color: #10b981;
                margin: 0;
                display: flex;
                align-items: center;
                gap: 10px;
            }
            .newsblogify-badge {
                font-size: 10px;
                text-transform: uppercase;
                background: rgba(16,185,129,0.15);
                color: #10b981;
                border: 1px solid rgba(16,185,129,0.3);
                padding: 3px 8px;
                border-radius: 8px;
                font-weight: bold;
            }
            .newsblogify-badge.error {
                background: rgba(239,68,68,0.15);
                color: #ef4444;
                border: 1px solid rgba(239,68,68,0.3);
            }
            .newsblogify-card {
                background: #1e293b;
                border-radius: 12px;
                padding: 20px;
                margin-bottom: 20px;
                border: 1px solid #334155;
            }
            .newsblogify-grid {
                display: grid;
                grid-template-cols: repeat(auto-fit, minmax(220px, 1fr));
                gap: 15px;
                margin-bottom: 20px;
            }
            .newsblogify-kpi {
                background: #1e293b;
                border: 1px solid #334155;
                border-radius: 12px;
                padding: 15px;
                text-align: center;
            }
            .newsblogify-kpi-label {
                font-size: 10px;
                color: #94a3b8;
                text-transform: uppercase;
                margin-bottom: 5px;
                font-weight: 600;
            }
            .newsblogify-kpi-value {
                font-size: 20px;
                font-weight: 700;
                color: #f8fafc;
            }
            .newsblogify-form-group {
                margin-bottom: 15px;
            }
            .newsblogify-form-group label {
                display: block;
                font-size: 11px;
                text-transform: uppercase;
                color: #94a3b8;
                margin-bottom: 6px;
                font-weight: bold;
            }
            .newsblogify-form-group input[type='text'], 
            .newsblogify-form-group input[type='password'],
            .newsblogify-form-group input[type='email'] {
                width: 100%;
                background: #0f172a;
                border: 1px solid #334155;
                color: #f8fafc;
                padding: 10px;
                border-radius: 8px;
                font-family: monospace;
            }
            .newsblogify-form-group input:focus {
                border-color: #10b981;
                outline: none;
            }
            .newsblogify-btn {
                background: #10b981;
                color: #0f172a;
                border: none;
                padding: 10px 20px;
                border-radius: 8px;
                font-weight: bold;
                cursor: pointer;
                transition: opacity 0.2s;
            }
            .newsblogify-btn:hover {
                opacity: 0.9;
            }
            .newsblogify-btn-secondary {
                background: #334155;
                color: #f8fafc;
                border: 1px solid #475569;
            }
            .newsblogify-tab-content {
                display: none;
            }
            .newsblogify-tab-content.active {
                display: block;
            }
            .newsblogify-tabs-nav {
                display: flex;
                gap: 10px;
                margin-bottom: 20px;
                border-bottom: 1px solid #1e293b;
                padding-bottom: 10px;
            }
            .newsblogify-tab-link {
                background: transparent;
                border: none;
                color: #94a3b8;
                cursor: pointer;
                font-weight: 600;
                padding: 5px 10px;
                transition: color 0.2s;
            }
            .newsblogify-tab-link.active {
                color: #10b981;
                border-bottom: 2px solid #10b981;
            }
            .newsblogify-logs-textarea {
                width: 100%;
                height: 300px;
                background: #090d16;
                color: #38bdf8;
                font-family: monospace;
                padding: 15px;
                border-radius: 8px;
                border: 1px solid #1e293b;
                font-size: 11px;
                line-height: 1.5;
            }
        ";
        wp_add_inline_style( 'newsblogify-admin-css', $custom_css );

        // Simple Tab switcher script
        wp_register_script( 'newsblogify-admin-js', false );
        wp_enqueue_script( 'newsblogify-admin-js' );
        $tab_script = "
            document.addEventListener('DOMContentLoaded', function() {
                const links = document.querySelectorAll('.newsblogify-tab-link');
                const contents = document.querySelectorAll('.newsblogify-tab-content');
                
                links.forEach(link => {
                    link.addEventListener('click', function(e) {
                        e.preventDefault();
                        const tab = this.getAttribute('data-tab');
                        
                        links.forEach(l => l.classList.remove('active'));
                        contents.forEach(c => c.classList.remove('active'));
                        
                        this.classList.add('active');
                        const target = document.getElementById('tab-' + tab);
                        if (target) {
                            target.classList.add('active');
                        }
                    });
                });
            });
        ";
        wp_add_inline_script( 'newsblogify-admin-js', $tab_script );
    }

    /**
     * Register target menu in WP Admin sidebar.
     */
    public function register_admin_pages() {
        add_menu_page(
            'NewsBlogify',
            'NewsBlogify',
            'manage_options',
            'newsblogify',
            [ $this, 'render_dashboard' ],
            'dashicons-admin-network',
            80
        );
    }

    /**
     * Handle form submissions and administrative commands.
     */
    public function handle_form_submissions() {
        if ( ! isset( $_POST['newsblogify_action'] ) ) {
            return;
        }

        check_admin_referer( 'newsblogify_admin_nonce_action', 'newsblogify_admin_nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Unauthorized access.' );
        }

        $action = sanitize_text_field( $_POST['newsblogify_action'] );

        if ( 'save_settings' === $action ) {
            $backend_url = esc_url_raw( $_POST['backend_url'] );
            $api_token   = sanitize_text_field( $_POST['api_token'] );
            $debug_mode  = isset( $_POST['debug_mode'] ) ? '1' : '0';

            update_option( 'newsblogify_backend_url', $backend_url );
            update_option( 'newsblogify_api_token', $api_token );
            update_option( 'newsblogify_debug_mode', $debug_mode );

            Logger::get_instance()->log( 'info', 'Settings updated manually.' );
            $this->redirect_with_query( [ 'settings_saved' => '1' ] );
        }

        if ( 'connect_wizard' === $action ) {
            $backend_url = esc_url_raw( $_POST['backend_url'] );
            $api_token   = sanitize_text_field( $_POST['api_token'] );
            $site_name   = sanitize_text_field( $_POST['site_name'] );
            $site_url    = get_site_url();
            $admin_email = get_option( 'admin_email' );

            $result = API_Client::get_instance()->register_site( $backend_url, $api_token, $site_name, $site_url, $admin_email );

            if ( is_wp_error( $result ) ) {
                $this->redirect_with_query( [ 'error_msg' => urlencode( $result->get_error_message() ) ] );
            }

            // Save site details
            $data = isset( $result['data'] ) ? $result['data'] : $result;
            $site_id = isset( $data['id'] ) ? $data['id'] : '';

            update_option( 'newsblogify_backend_url', $backend_url );
            update_option( 'newsblogify_api_token', $api_token );
            update_option( 'newsblogify_site_id', $site_id );
            update_option( 'newsblogify_site_name', $site_name );
            update_option( 'newsblogify_connection_status', 'connected' );
            update_option( 'newsblogify_last_sync_time', current_time( 'mysql' ) );

            Logger::get_instance()->log( 'info', 'Setup wizard completed. Site ID: ' . $site_id );
            $this->redirect_with_query( [ 'setup_completed' => '1' ] );
        }

        if ( 'test_connection' === $action ) {
            $backend_url = get_option( 'newsblogify_backend_url', '' );
            $api_token   = get_option( 'newsblogify_api_token', '' );

            $res = API_Client::get_instance()->test_connection( $backend_url, $api_token );
            if ( is_wp_error( $res ) ) {
                update_option( 'newsblogify_connection_status', 'disconnected' );
                $this->redirect_with_query( [ 'error_msg' => urlencode( $res->get_error_message() ) ] );
            }

            update_option( 'newsblogify_connection_status', 'connected' );
            $this->redirect_with_query( [ 'test_success' => '1' ] );
        }

        if ( 'force_sync' === $action ) {
            Cron::get_instance()->run_configuration_sync();
            $this->redirect_with_query( [ 'sync_success' => '1' ] );
        }

        if ( 'disconnect' === $action ) {
            update_option( 'newsblogify_site_id', '' );
            update_option( 'newsblogify_connection_status', 'disconnected' );
            Logger::get_instance()->log( 'info', 'Website disconnected manually by admin.' );
            $this->redirect_with_query( [ 'disconnected' => '1' ] );
        }

        if ( 'clear_logs' === $action ) {
            Logger::get_instance()->clear_logs();
            $this->redirect_with_query( [ 'logs_cleared' => '1' ] );
        }
    }

    private function redirect_with_query( $params ) {
        $url = add_query_arg( $params, admin_url( 'admin.php?page=newsblogify' ) );
        wp_safe_redirect( $url );
        exit;
    }

    /**
     * Render HTML UI for Dashboard and Setup Wizard.
     */
    public function render_dashboard() {
        $site_id = get_option( 'newsblogify_site_id', '' );
        $is_connected = get_option( 'newsblogify_connection_status', 'disconnected' ) === 'connected';

        echo '<div class="wrap">';
        echo '<div class="newsblogify-container">';

        // Render Wizard if site is not registered yet
        if ( empty( $site_id ) ) {
            $this->render_setup_wizard();
        } else {
            $this->render_dashboard_panels( $is_connected );
        }

        echo '</div>';
        echo '</div>';
    }

    private function render_setup_wizard() {
        ?>
        <div class="newsblogify-header">
            <h1 class="newsblogify-title">
                <span class="material-symbols-outlined">network_ping</span> NewsBlogify Setup Wizard
            </h1>
            <span class="newsblogify-badge error">Not Connected</span>
        </div>

        <?php if ( isset( $_GET['error_msg'] ) ) : ?>
            <div class="newsblogify-card" style="border-color: #ef4444; background: rgba(239,68,68,0.05);">
                <p style="color: #ef4444; font-weight: bold; margin: 0;">Connection Failed: <?php echo esc_html( urldecode( $_GET['error_msg'] ) ); ?></p>
            </div>
        <?php endif; ?>

        <form method="post" action="">
            <?php wp_nonce_field( 'newsblogify_admin_nonce_action', 'newsblogify_admin_nonce' ); ?>
            <input type="hidden" name="newsblogify_action" value="connect_wizard" />

            <div class="newsblogify-card">
                <h3 style="margin-top: 0; color: #10b981;">Step 1: Website Metadata</h3>
                <div class="newsblogify-form-group">
                    <label>Website Name</label>
                    <input type="text" name="site_name" value="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" required />
                </div>
                <div class="newsblogify-form-group">
                    <label>Website Public URL</label>
                    <input type="text" value="<?php echo esc_url( get_site_url() ); ?>" readonly style="background: #1e293b; cursor: not-allowed;" />
                </div>
            </div>

            <div class="newsblogify-card">
                <h3 style="margin-top: 0; color: #10b981;">Step 2: API Credentials</h3>
                <div class="newsblogify-form-group">
                    <label>NewsBlogify Backend URL</label>
                    <input type="text" name="backend_url" value="http://127.0.0.1:8000" placeholder="e.g. http://127.0.0.1:8000" required />
                </div>
                <div class="newsblogify-form-group">
                    <label>API Access Token / Bearer Token</label>
                    <input type="password" name="api_token" placeholder="Paste your API key/token here" required />
                </div>
            </div>

            <div style="text-align: right;">
                <button type="submit" class="newsblogify-btn">Connect &amp; Register Website</button>
            </div>
        </form>
        <?php
    }

    private function render_dashboard_panels( $is_connected ) {
        $backend_url = get_option( 'newsblogify_backend_url', '' );
        $api_token   = get_option( 'newsblogify_api_token', '' );
        $site_id     = get_option( 'newsblogify_site_id', '' );
        $site_name   = get_option( 'newsblogify_site_name', '' );
        $debug_mode  = get_option( 'newsblogify_debug_mode', '0' );
        $last_sync   = get_option( 'newsblogify_last_sync_time', 'Never' );
        $slot        = get_option( 'newsblogify_posting_slot', 'Daily' );
        $topics      = get_option( 'newsblogify_selected_topics', [] );

        ?>
        <div class="newsblogify-header">
            <h1 class="newsblogify-title">NewsBlogify Automation Dashboard</h1>
            <span class="newsblogify-badge <?php echo $is_connected ? '' : 'error'; ?>">
                <?php echo $is_connected ? 'Connected' : 'Disconnected'; ?>
            </span>
        </div>

        <?php if ( isset( $_GET['settings_saved'] ) ) : ?>
            <div class="newsblogify-card" style="border-color: #10b981; background: rgba(16,185,129,0.05); padding: 12px 20px;">
                <p style="color: #10b981; font-weight: bold; margin: 0;">Settings saved successfully.</p>
            </div>
        <?php elseif ( isset( $_GET['test_success'] ) ) : ?>
            <div class="newsblogify-card" style="border-color: #10b981; background: rgba(16,185,129,0.05); padding: 12px 20px;">
                <p style="color: #10b981; font-weight: bold; margin: 0;">Connection check: Connection successful!</p>
            </div>
        <?php elseif ( isset( $_GET['sync_success'] ) ) : ?>
            <div class="newsblogify-card" style="border-color: #10b981; background: rgba(16,185,129,0.05); padding: 12px 20px;">
                <p style="color: #10b981; font-weight: bold; margin: 0;">Synchronization completed successfully.</p>
            </div>
        <?php elseif ( isset( $_GET['error_msg'] ) ) : ?>
            <div class="newsblogify-card" style="border-color: #ef4444; background: rgba(239,68,68,0.05); padding: 12px 20px;">
                <p style="color: #ef4444; font-weight: bold; margin: 0;">Error: <?php echo esc_html( urldecode( $_GET['error_msg'] ) ); ?></p>
            </div>
        <?php endif; ?>

        <div class="newsblogify-tabs-nav">
            <button class="newsblogify-tab-link active" data-tab="status">Status &amp; Telemetry</button>
            <button class="newsblogify-tab-link" data-tab="settings">Settings</button>
            <button class="newsblogify-tab-link" data-tab="logs">System Logs</button>
        </div>

        <!-- TAB: Status & Telemetry -->
        <div id="tab-status" class="newsblogify-tab-content active">
            <div class="newsblogify-grid">
                <div class="newsblogify-kpi">
                    <div class="newsblogify-kpi-label">Site Identifier</div>
                    <div class="newsblogify-kpi-value" style="font-family: monospace; font-size: 15px; color: #10b981;"><?php echo esc_html( $site_id ); ?></div>
                </div>
                <div class="newsblogify-kpi">
                    <div class="newsblogify-kpi-label">Last Sync Telemetry</div>
                    <div class="newsblogify-kpi-value" style="font-size: 14px;"><?php echo esc_html( $last_sync ); ?></div>
                </div>
                <div class="newsblogify-kpi">
                    <div class="newsblogify-kpi-label">Schedule Slot</div>
                    <div class="newsblogify-kpi-value"><?php echo esc_html( $slot ); ?></div>
                </div>
                <div class="newsblogify-kpi">
                    <div class="newsblogify-kpi-label">Subscription Status</div>
                    <div class="newsblogify-kpi-value" style="color: #10b981;">Active</div>
                </div>
            </div>

            <div class="newsblogify-card">
                <h3 style="margin-top: 0; color: #10b981;">Configured Topic Clusters</h3>
                <?php if ( empty( $topics ) ) : ?>
                    <p style="color: #94a3b8; font-style: italic; font-size: 13px;">No topics synced from backend. Force synchronization to download settings.</p>
                <?php else : ?>
                    <div style="display: flex; flex-wrap: wrap; gap: 8px;">
                        <?php foreach ( $topics as $topic ) : ?>
                            <span class="newsblogify-badge" style="background: #334155; color: #f8fafc; border-color: #475569; text-transform: none;">
                                <?php echo esc_html( $topic ); ?>
                            </span>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>

            <div style="display: flex; gap: 10px;">
                <form method="post" action="">
                    <?php wp_nonce_field( 'newsblogify_admin_nonce_action', 'newsblogify_admin_nonce' ); ?>
                    <input type="hidden" name="newsblogify_action" value="test_connection" />
                    <button type="submit" class="newsblogify-btn">Test Connection</button>
                </form>

                <form method="post" action="">
                    <?php wp_nonce_field( 'newsblogify_admin_nonce_action', 'newsblogify_admin_nonce' ); ?>
                    <input type="hidden" name="newsblogify_action" value="force_sync" />
                    <button type="submit" class="newsblogify-btn newsblogify-btn-secondary">Sync Now</button>
                </form>

                <form method="post" action="" onsubmit="return confirm('Are you sure you want to disconnect this website?');">
                    <?php wp_nonce_field( 'newsblogify_admin_nonce_action', 'newsblogify_admin_nonce' ); ?>
                    <input type="hidden" name="newsblogify_action" value="disconnect" />
                    <button type="submit" class="newsblogify-btn" style="background: #ef4444; color: #fff;">Disconnect Site</button>
                </form>
            </div>
        </div>

        <!-- TAB: Settings -->
        <div id="tab-settings" class="newsblogify-tab-content">
            <form method="post" action="">
                <?php wp_nonce_field( 'newsblogify_admin_nonce_action', 'newsblogify_admin_nonce' ); ?>
                <input type="hidden" name="newsblogify_action" value="save_settings" />

                <div class="newsblogify-card">
                    <div class="newsblogify-form-group">
                        <label>NewsBlogify Backend URL</label>
                        <input type="text" name="backend_url" value="<?php echo esc_url( $backend_url ); ?>" required />
                    </div>

                    <div class="newsblogify-form-group">
                        <label>API Access Token / Bearer Token</label>
                        <input type="password" name="api_token" value="<?php echo esc_attr( $api_token ); ?>" required />
                    </div>

                    <div class="newsblogify-form-group" style="display: flex; align-items: center; gap: 8px;">
                        <input type="checkbox" name="debug_mode" id="debug_mode" value="1" <?php checked( $debug_mode, '1' ); ?> />
                        <label for="debug_mode" style="margin: 0; display: inline; cursor: pointer;">Enable System Debug Logging</label>
                    </div>
                </div>

                <button type="submit" class="newsblogify-btn">Save Settings</button>
            </form>
        </div>

        <!-- TAB: Logs -->
        <div id="tab-logs" class="newsblogify-tab-content">
            <div class="newsblogify-card">
                <h3 style="margin-top: 0; color: #10b981; display: flex; justify-content: space-between; align-items: center;">
                    System Activity Logs
                    <form method="post" action="" style="display: inline;" onsubmit="return confirm('Clear all log history?');">
                        <?php wp_nonce_field( 'newsblogify_admin_nonce_action', 'newsblogify_admin_nonce' ); ?>
                        <input type="hidden" name="newsblogify_action" value="clear_logs" />
                        <button type="submit" class="newsblogify-btn newsblogify-btn-secondary" style="font-size: 11px; padding: 4px 10px;">Clear Logs</button>
                    </form>
                </h3>
                <textarea class="newsblogify-logs-textarea" readonly><?php echo esc_textarea( Logger::get_instance()->get_logs( 150 ) ); ?></textarea>
            </div>
        </div>
        <?php
    }
}
