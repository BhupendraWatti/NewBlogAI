<?php
namespace NewsBlogify;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Admin {
    private static $instance = null;

    private function __construct() {
        add_action( 'admin_menu', [ $this, 'register_admin_pages' ] );
        add_action( 'admin_init', [ $this, 'handle_form_submissions' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
    }

    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Enqueue native styling overrides and UI scripts.
     */
    public function enqueue_assets( $hook ) {
        if ( strpos( $hook, 'newsblogify' ) === false ) {
            return;
        }

        wp_register_style( 'newsblogify-admin-css', false );
        wp_enqueue_style( 'newsblogify-admin-css' );

        // Premium WordPress light-themed stylesheet matching Rank Math / Jetpack
        $custom_css = "
            .newsblogify-wrap {
                margin: 20px 20px 0 0;
                max-width: 1200px;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen-Sans, Ubuntu, Cantarell, 'Helvetica Neue', sans-serif;
            }
            .newsblogify-header-banner {
                background: #ffffff;
                border: 1px solid #ccd0d4;
                border-radius: 8px;
                padding: 24px 30px;
                margin-bottom: 25px;
                display: flex;
                align-items: center;
                justify-content: space-between;
                box-shadow: 0 1px 15px rgba(0,0,0,0.05);
            }
            .newsblogify-brand {
                display: flex;
                align-items: center;
                gap: 15px;
            }
            .newsblogify-brand h1 {
                font-size: 24px;
                font-weight: 700;
                color: #1e1e1e;
                margin: 0;
            }
            .newsblogify-tagline {
                color: #646970;
                margin: 5px 0 0 0;
                font-size: 13px;
            }
            .newsblogify-logo-icon {
                font-size: 32px;
                color: #2271b1;
                display: flex;
                align-items: center;
            }
            .newsblogify-grid {
                display: grid;
                grid-template-cols: repeat(auto-fit, minmax(280px, 1fr));
                gap: 20px;
                margin-bottom: 25px;
            }
            .newsblogify-card {
                background: #ffffff;
                border: 1px solid #ccd0d4;
                border-radius: 8px;
                padding: 20px;
                box-shadow: 0 1px 1px rgba(0,0,0,0.04);
                box-sizing: border-box;
            }
            .newsblogify-card h2 {
                font-size: 16px;
                font-weight: 600;
                margin-top: 0;
                margin-bottom: 15px;
                padding-bottom: 10px;
                border-bottom: 1px solid #f0f0f1;
                display: flex;
                align-items: center;
                gap: 8px;
                color: #1e1e1e;
            }
            .newsblogify-metric-value {
                font-size: 28px;
                font-weight: 700;
                color: #2271b1;
                line-height: 1.2;
            }
            .newsblogify-metric-desc {
                font-size: 12px;
                color: #646970;
                margin-top: 4px;
            }
            .newsblogify-badge-active {
                background: #dff2e3;
                color: #107c10;
                padding: 4px 10px;
                border-radius: 4px;
                font-size: 11px;
                font-weight: 600;
                text-transform: uppercase;
                display: inline-block;
            }
            .newsblogify-badge-inactive {
                background: #fcf0f0;
                color: #d11a2a;
                padding: 4px 10px;
                border-radius: 4px;
                font-size: 11px;
                font-weight: 600;
                text-transform: uppercase;
                display: inline-block;
            }
            /* Setup Wizard Styling */
            .newsblogify-wizard-container {
                max-width: 650px;
                margin: 40px auto;
                background: #ffffff;
                border: 1px solid #ccd0d4;
                border-radius: 12px;
                box-shadow: 0 3px 30px rgba(0,0,0,0.08);
                overflow: hidden;
            }
            .newsblogify-wizard-header {
                background: #2271b1;
                color: #ffffff;
                padding: 30px;
                text-align: center;
            }
            .newsblogify-wizard-header h2 {
                color: #ffffff;
                margin: 0;
                font-size: 22px;
                font-weight: 700;
            }
            .newsblogify-wizard-steps {
                display: flex;
                justify-content: space-around;
                background: #f6f7f7;
                border-bottom: 1px solid #dcdcde;
                padding: 15px 10px;
            }
            .newsblogify-wizard-step {
                font-size: 12px;
                font-weight: 600;
                color: #8c8f94;
                display: flex;
                align-items: center;
                gap: 6px;
            }
            .newsblogify-wizard-step.active {
                color: #2271b1;
            }
            .newsblogify-wizard-step.completed {
                color: #107c10;
            }
            .newsblogify-wizard-body {
                padding: 35px;
            }
            /* Table form layout helper */
            .newsblogify-wizard-table {
                width: 100%;
                margin-bottom: 20px;
            }
            .newsblogify-wizard-table td {
                padding: 10px 0;
                vertical-align: middle;
            }
            .newsblogify-wizard-table td.label-column {
                width: 30%;
                font-weight: 600;
                color: #3c434a;
            }
            .newsblogify-wizard-input {
                width: 100%;
                padding: 8px 12px;
                border: 1px solid #8c8f94;
                border-radius: 6px;
                font-size: 13px;
            }
            .newsblogify-wizard-input[readonly] {
                background: #f6f7f7;
                color: #646970;
                border-color: #dcdcde;
            }
            /* Tab content navigation toggles */
            .newsblogify-tab-content {
                display: none;
            }
            .newsblogify-tab-content.active {
                display: block;
            }
            .newsblogify-nav-tab-wrapper {
                margin-bottom: 20px;
            }
            .newsblogify-log-textarea {
                width: 100%;
                height: 350px;
                font-family: Consolas, Monaco, monospace;
                font-size: 12px;
                line-height: 1.6;
                background: #f6f7f7;
                color: #2c3338;
                padding: 15px;
                border: 1px solid #ccd0d4;
                border-radius: 6px;
                box-sizing: border-box;
            }
        ";
        wp_add_inline_style( 'newsblogify-admin-css', $custom_css );

        wp_register_script( 'newsblogify-admin-js', false );
        wp_enqueue_script( 'newsblogify-admin-js' );

        $tab_script = "
            document.addEventListener('DOMContentLoaded', function() {
                const tabs = document.querySelectorAll('.newsblogify-nav-tab');
                const panes = document.querySelectorAll('.newsblogify-tab-content');

                tabs.forEach(tab => {
                    tab.addEventListener('click', function(e) {
                        e.preventDefault();
                        const targetPane = this.getAttribute('data-tab');

                        tabs.forEach(t => t.classList.remove('nav-tab-active'));
                        panes.forEach(p => p.classList.remove('active'));

                        this.classList.add('nav-tab-active');
                        const activePane = document.getElementById('tab-' + targetPane);
                        if (activePane) {
                            activePane.classList.add('active');
                        }
                    });
                });
            });
        ";
        wp_add_inline_script( 'newsblogify-admin-js', $tab_script );
    }

    /**
     * Register target menu in WP Admin sidebar.
     */
    public function register_admin_pages() {
        add_menu_page(
            'NewsBlogify',
            'NewsBlogify',
            'manage_options',
            'newsblogify',
            [ $this, 'render_dashboard' ],
            'dashicons-admin-network',
            80
        );
    }

    /**
     * Handle form submissions and administrative commands.
     */
    public function handle_form_submissions() {
        if ( ! isset( $_POST['newsblogify_action'] ) ) {
            return;
        }

        check_admin_referer( 'newsblogify_admin_nonce_action', 'newsblogify_admin_nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Unauthorized access.' );
        }

        $action = sanitize_text_field( $_POST['newsblogify_action'] );

        if ( 'wizard_step1' === $action ) {
            $backend_url = esc_url_raw( $_POST['backend_url'] );
            $email       = sanitize_email( $_POST['email'] );
            $password    = $_POST['password'];

            $res = API_Client::get_instance()->connect_account( $backend_url, $email, $password );

            if ( is_wp_error( $res ) ) {
                $this->redirect_with_query( [ 'error_msg' => urlencode( $res->get_error_message() ) ] );
            }

            // Connection successful, store credentials
            update_option( 'newsblogify_backend_url', $backend_url );
            update_option( 'newsblogify_api_token', $res['access_token'] );
            update_option( 'newsblogify_account_email', $email );
            update_option( 'newsblogify_wizard_step', '2' );

            Logger::get_instance()->log( 'info', 'Setup Wizard Step 1: Connected account ' . $email );
            $this->redirect_with_query( [] );
        }

        if ( 'wizard_step2' === $action ) {
            $site_name   = sanitize_text_field( $_POST['site_name'] );
            $wp_app_pwd  = sanitize_text_field( $_POST['wp_app_pwd'] );
            $site_url    = get_site_url();
            $backend_url = get_option( 'newsblogify_backend_url', '' );
            $api_token   = get_option( 'newsblogify_api_token', '' );

            // Validate domain and store on backend
            $res = API_Client::get_instance()->register_site( $backend_url, $api_token, $site_name, $site_url, $wp_app_pwd );

            if ( is_wp_error( $res ) ) {
                $this->redirect_with_query( [ 'error_msg' => urlencode( $res->get_error_message() ) ] );
            }

            $site_id = isset( $res['site_id'] ) ? $res['site_id'] : '';
            $config  = isset( $res['configuration'] ) ? $res['configuration'] : [];

            update_option( 'newsblogify_site_id', $site_id );
            update_option( 'newsblogify_site_name', $site_name );
            update_option( 'newsblogify_wp_app_pwd', $wp_app_pwd );
            update_option( 'newsblogify_posting_slot', isset( $config['slot'] ) ? $config['slot'] : 'Daily' );
            update_option( 'newsblogify_selected_topics', isset( $config['selected_topics'] ) ? $config['selected_topics'] : [] );
            update_option( 'newsblogify_connection_status', 'connected' );
            update_option( 'newsblogify_last_sync_time', current_time( 'mysql' ) );
            update_option( 'newsblogify_wizard_step', 'completed' );

            Logger::get_instance()->log( 'info', 'Setup Wizard completed. Stored site ID: ' . $site_id );
            $this->redirect_with_query( [] );
        }

        if ( 'wizard_reset' === $action || 'disconnect' === $action ) {
            // Send disconnect call to backend
            $site_id = get_option( 'newsblogify_site_id', '' );
            if ( ! empty( $site_id ) ) {
                API_Client::get_instance()->request( '/disconnect', 'POST' );
            }

            // Wipe out all configuration options
            delete_option( 'newsblogify_backend_url' );
            delete_option( 'newsblogify_api_token' );
            delete_option( 'newsblogify_account_email' );
            delete_option( 'newsblogify_site_id' );
            delete_option( 'newsblogify_site_name' );
            delete_option( 'newsblogify_wp_app_pwd' );
            delete_option( 'newsblogify_posting_slot' );
            delete_option( 'newsblogify_selected_topics' );
            delete_option( 'newsblogify_connection_status' );
            delete_option( 'newsblogify_wizard_step' );
            delete_option( 'newsblogify_last_sync_time' );

            Logger::get_instance()->log( 'info', 'Plugin state reset. Disconnected from backend.' );
            $this->redirect_with_query( [ 'disconnected' => '1' ] );
        }

        if ( 'test_connection' === $action ) {
            $site_url = get_site_url();
            $res = API_Client::get_instance()->request( '/status?site_url=' . urlencode( $site_url ) );
            if ( is_wp_error( $res ) ) {
                update_option( 'newsblogify_connection_status', 'disconnected' );
                $this->redirect_with_query( [ 'error_msg' => urlencode( $res->get_error_message() ) ] );
            }

            update_option( 'newsblogify_connection_status', 'connected' );
            $this->redirect_with_query( [ 'test_success' => '1' ] );
        }

        if ( 'force_sync' === $action ) {
            $site_url = get_site_url();
            $res = API_Client::get_instance()->request( '/sync?site_url=' . urlencode( $site_url ), 'POST' );
            if ( is_wp_error( $res ) ) {
                $this->redirect_with_query( [ 'error_msg' => urlencode( $res->get_error_message() ) ] );
            }

            $config = isset( $res['configuration'] ) ? $res['configuration'] : [];
            update_option( 'newsblogify_posting_slot', isset( $config['slot'] ) ? $config['slot'] : 'Daily' );
            update_option( 'newsblogify_selected_topics', isset( $config['selected_topics'] ) ? $config['selected_topics'] : [] );
            update_option( 'newsblogify_last_sync_time', current_time( 'mysql' ) );

            Logger::get_instance()->log( 'info', 'Forced configuration sync complete.' );
            $this->redirect_with_query( [ 'sync_success' => '1' ] );
        }

        if ( 'refresh_token' === $action ) {
            $res = API_Client::get_instance()->request( '/refresh-token', 'POST' );
            if ( is_wp_error( $res ) ) {
                $this->redirect_with_query( [ 'error_msg' => urlencode( $res->get_error_message() ) ] );
            }

            if ( isset( $res['access_token'] ) ) {
                update_option( 'newsblogify_api_token', $res['access_token'] );
            }

            Logger::get_instance()->log( 'info', 'Token refreshed successfully.' );
            $this->redirect_with_query( [ 'token_refreshed' => '1' ] );
        }

        if ( 'clear_logs' === $action ) {
            Logger::get_instance()->clear_logs();
            $this->redirect_with_query( [ 'logs_cleared' => '1' ] );
        }

        if ( 'save_advanced' === $action ) {
            $debug_mode = isset( $_POST['debug_mode'] ) ? '1' : '0';
            update_option( 'newsblogify_debug_mode', $debug_mode );
            $this->redirect_with_query( [ 'settings_saved' => '1' ] );
        }
    }

    private function redirect_with_query( $params ) {
        $url = add_query_arg( $params, admin_url( 'admin.php?page=newsblogify' ) );
        wp_safe_redirect( $url );
        exit;
    }

    /**
     * Render main dashboard view.
     */
    public function render_dashboard() {
        $wizard_step = get_option( 'newsblogify_wizard_step', '1' );

        echo '<div class="newsblogify-wrap">';

        if ( 'completed' !== $wizard_step ) {
            $this->render_wizard_wizard( $wizard_step );
        } else {
            $this->render_dashboard_panels();
        }

        echo '</div>';
    }

    /**
     * Render Setup Wizard Screens.
     */
    private function render_wizard_wizard( $step ) {
        ?>
        <div class="newsblogify-wizard-container">
            <div class="newsblogify-wizard-header">
                <h2>Welcome to NewsBlogify</h2>
                <div style="font-size: 13px; margin-top: 5px; opacity: 0.85;">AI WordPress Content Automation Onboarding</div>
            </div>

            <div class="newsblogify-wizard-steps">
                <div class="newsblogify-wizard-step <?php echo '1' === $step ? 'active' : 'completed'; ?>">
                    <span class="dashicons dashicons-admin-users"></span> 1. Connect Account
                </div>
                <div class="newsblogify-wizard-step <?php echo '2' === $step ? 'active' : ''; ?>">
                    <span class="dashicons dashicons-admin-site-alt3"></span> 2. Register Site
                </div>
            </div>

            <div class="newsblogify-wizard-body">
                <?php if ( isset( $_GET['error_msg'] ) ) : ?>
                    <div class="notice notice-error is-dismissible" style="margin-left:0; margin-bottom: 20px;">
                        <p><?php echo esc_html( urldecode( $_GET['error_msg'] ) ); ?></p>
                    </div>
                <?php endif; ?>

                <?php if ( '1' === $step ) : ?>
                    <!-- WIZARD STEP 1: Connect Account -->
                    <form method="post" action="">
                        <?php wp_nonce_field( 'newsblogify_admin_nonce_action', 'newsblogify_admin_nonce' ); ?>
                        <input type="hidden" name="newsblogify_action" value="wizard_step1" />

                        <p style="margin-top:0; color: #646970; font-size: 14px;">Connect this WordPress installation to your NewsBlogify SaaS dashboard account to begin.</p>
                        
                        <table class="newsblogify-wizard-table">
                            <tr>
                                <td class="label-column"><label>Backend Service URL</label></td>
                                <td><input type="text" class="newsblogify-wizard-input" name="backend_url" value="http://127.0.0.1:8000" required /></td>
                            </tr>
                            <tr>
                                <td class="label-column"><label>Account Email</label></td>
                                <td><input type="email" class="newsblogify-wizard-input" name="email" value="<?php echo esc_attr( get_option( 'admin_email' ) ); ?>" required /></td>
                            </tr>
                            <tr>
                                <td class="label-column"><label>Account Password</label></td>
                                <td><input type="password" class="newsblogify-wizard-input" name="password" required /></td>
                            </tr>
                        </table>

                        <div style="text-align: right; margin-top: 25px;">
                            <button type="submit" class="button button-primary button-large">Connect &amp; Authenticate</button>
                        </div>
                    </form>

                <?php else : ?>
                    <!-- WIZARD STEP 2: Website Registration -->
                    <form method="post" action="">
                        <?php wp_nonce_field( 'newsblogify_admin_nonce_action', 'newsblogify_admin_nonce' ); ?>
                        <input type="hidden" name="newsblogify_action" value="wizard_step2" />

                        <p style="margin-top:0; color: #646970; font-size: 14px;">Review and submit your local site metadata to establish remote posting verification.</p>

                        <table class="newsblogify-wizard-table">
                            <tr>
                                <td class="label-column"><label>Website Name</label></td>
                                <td><input type="text" class="newsblogify-wizard-input" name="site_name" value="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" required /></td>
                            </tr>
                            <tr>
                                <td class="label-column"><label>Website Public URL</label></td>
                                <td><input type="text" class="newsblogify-wizard-input" value="<?php echo esc_url( get_site_url() ); ?>" readonly /></td>
                            </tr>
                            <tr>
                                <td class="label-column"><label>WordPress Version</label></td>
                                <td><input type="text" class="newsblogify-wizard-input" value="<?php echo esc_attr( get_bloginfo( 'version' ) ); ?>" readonly /></td>
                            </tr>
                            <tr>
                                <td class="label-column"><label>PHP Version</label></td>
                                <td><input type="text" class="newsblogify-wizard-input" value="<?php echo esc_attr( phpversion() ); ?>" readonly /></td>
                            </tr>
                            <tr>
                                <td class="label-column"><label>WordPress App Password</label></td>
                                <td>
                                    <input type="password" class="newsblogify-wizard-input" name="wp_app_pwd" required />
                                    <p class="description" style="margin-top: 4px; font-size: 11px;">Generate an <strong>Application Password</strong> in Users -> Profile to secure publishing endpoints.</p>
                                </td>
                            </tr>
                        </table>

                        <div style="display: flex; justify-content: space-between; margin-top: 25px;">
                            <button type="submit" name="newsblogify_action" value="wizard_reset" class="button button-link" style="color: #d11a2a;">Reset Wizard</button>
                            <button type="submit" class="button button-primary button-large">Register &amp; Finish Setup</button>
                        </div>
                    </form>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }

    /**
     * Render Completed Dashboard and Settings panels.
     */
    private function render_dashboard_panels() {
        $is_connected = get_option( 'newsblogify_connection_status', 'disconnected' ) === 'connected';
        $backend_url  = get_option( 'newsblogify_backend_url', '' );
        $email        = get_option( 'newsblogify_account_email', '' );
        $site_id      = get_option( 'newsblogify_site_id', '' );
        $site_name    = get_option( 'newsblogify_site_name', '' );
        $slot         = get_option( 'newsblogify_posting_slot', 'Daily' );
        $topics       = get_option( 'newsblogify_selected_topics', [] );
        $last_sync    = get_option( 'newsblogify_last_sync_time', 'Never' );
        $debug_mode   = get_option( 'newsblogify_debug_mode', '0' );

        // Notifications
        if ( isset( $_GET['test_success'] ) ) : ?>
            <div class="notice notice-success is-dismissible"><p>Connection verified successfully! Staging endpoint verified.</p></div>
        <?php elseif ( isset( $_GET['sync_success'] ) ) : ?>
            <div class="notice notice-success is-dismissible"><p>WordPress scheduling and topic configuration updated.</p></div>
        <?php elseif ( isset( $_GET['token_refreshed'] ) ) : ?>
            <div class="notice notice-success is-dismissible"><p>OAuth token refreshed successfully.</p></div>
        <?php elseif ( isset( $_GET['settings_saved'] ) ) : ?>
            <div class="notice notice-success is-dismissible"><p>Advanced settings saved.</p></div>
        <?php elseif ( isset( $_GET['error_msg'] ) ) : ?>
            <div class="notice notice-error is-dismissible"><p><?php echo esc_html( urldecode( $_GET['error_msg'] ) ); ?></p></div>
        <?php endif; ?>

        <!-- Dashboard Banner -->
        <div class="newsblogify-header-banner">
            <div class="newsblogify-brand">
                <span class="dashicons dashicons-admin-network newsblogify-logo-icon"></span>
                <div>
                    <h1>NewsBlogify Client Settings</h1>
                    <p class="newsblogify-tagline">Automated SEO Content Generation Dashboard</p>
                </div>
            </div>
            <div>
                <?php if ( $is_connected ) : ?>
                    <span class="newsblogify-badge-active"><span class="dashicons dashicons-yes" style="font-size:14px; width:14px; height:14px; vertical-align:middle; margin-right:4px;"></span> Connected</span>
                <?php else : ?>
                    <span class="newsblogify-badge-inactive"><span class="dashicons dashicons-warning" style="font-size:14px; width:14px; height:14px; vertical-align:middle; margin-right:4px;"></span> Disconnected</span>
                <?php endif; ?>
            </div>
        </div>

        <!-- Navigation Tabs -->
        <div class="newsblogify-nav-tab-wrapper nav-tab-wrapper">
            <a href="#" class="nav-tab nav-tab-active newsblogify-nav-tab" data-tab="status">Status &amp; Telemetry</a>
            <a href="#" class="nav-tab newsblogify-nav-tab" data-tab="connection">Connection</a>
            <a href="#" class="nav-tab newsblogify-nav-tab" data-tab="publishing">Publishing</a>
            <a href="#" class="nav-tab newsblogify-nav-tab" data-tab="sync">Synchronization</a>
            <a href="#" class="nav-tab newsblogify-nav-tab" data-tab="logs">System Logs</a>
            <a href="#" class="nav-tab newsblogify-nav-tab" data-tab="advanced">Advanced</a>
        </div>

        <!-- TAB CONTENT: Status & Telemetry -->
        <div id="tab-status" class="newsblogify-tab-content active">
            <div class="newsblogify-grid">
                <div class="newsblogify-card">
                    <h2><span class="dashicons dashicons-index-card"></span> Site Identifier</h2>
                    <div class="newsblogify-metric-value" style="font-size: 15px; font-family: monospace; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                        <?php echo esc_html( $site_id ); ?>
                    </div>
                    <div class="newsblogify-metric-desc">Registered site index ID.</div>
                </div>
                <div class="newsblogify-card">
                    <h2><span class="dashicons dashicons-backup"></span> Last Synchronized</h2>
                    <div class="newsblogify-metric-value" style="font-size: 20px;">
                        <?php echo esc_html( $last_sync ); ?>
                    </div>
                    <div class="newsblogify-metric-desc">Last category &amp; settings sync.</div>
                </div>
                <div class="newsblogify-card">
                    <h2><span class="dashicons dashicons-calendar-alt"></span> Posting Frequency</h2>
                    <div class="newsblogify-metric-value"><?php echo esc_html( $slot ); ?></div>
                    <div class="newsblogify-metric-desc">Scheduled automation publishing slot.</div>
                </div>
                <div class="newsblogify-card">
                    <h2><span class="dashicons dashicons-lock"></span> Subscription</h2>
                    <div class="newsblogify-metric-value" style="color: #107c10;">ACTIVE</div>
                    <div class="newsblogify-metric-desc">Plan limit: Unlimited (Dev mode)</div>
                </div>
            </div>

            <div class="newsblogify-card" style="margin-bottom: 25px;">
                <h2><span class="dashicons dashicons-category"></span> Synced Topic Clusters</h2>
                <?php if ( empty( $topics ) ) : ?>
                    <p style="color: #646970; font-style: italic;">No topic configurations downloaded. Run manual synchronization.</p>
                <?php else : ?>
                    <div style="display: flex; flex-wrap: wrap; gap: 8px;">
                        <?php foreach ( $topics as $topic ) : ?>
                            <span style="background: #f0f0f1; border: 1px solid #ccd0d4; padding: 4px 10px; border-radius: 4px; font-size:12px; color: #2c3338;">
                                <?php echo esc_html( $topic ); ?>
                            </span>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>

            <div class="newsblogify-card">
                <h2><span class="dashicons dashicons-admin-generic"></span> Operational Quick Actions</h2>
                <div style="display: flex; gap: 12px; flex-wrap: wrap;">
                    <form method="post" action="" style="display:inline;">
                        <?php wp_nonce_field( 'newsblogify_admin_nonce_action', 'newsblogify_admin_nonce' ); ?>
                        <input type="hidden" name="newsblogify_action" value="test_connection" />
                        <button type="submit" class="button button-secondary">Test Backend Connection</button>
                    </form>

                    <form method="post" action="" style="display:inline;">
                        <?php wp_nonce_field( 'newsblogify_admin_nonce_action', 'newsblogify_admin_nonce' ); ?>
                        <input type="hidden" name="newsblogify_action" value="force_sync" />
                        <button type="submit" class="button button-primary">Sync Now</button>
                    </form>

                    <a href="<?php echo esc_url( $backend_url ); ?>" target="_blank" class="button button-secondary">Open SaaS Dashboard <span class="dashicons dashicons-external" style="font-size:14px; width:14px; line-height:28px;"></span></a>
                </div>
            </div>
        </div>

        <!-- TAB CONTENT: Connection -->
        <div id="tab-connection" class="newsblogify-tab-content">
            <div class="newsblogify-card">
                <h2><span class="dashicons dashicons-admin-links"></span> Authentication Connection</h2>
                <table class="form-table">
                    <tr>
                        <th scope="row">Connected User</th>
                        <td><strong><?php echo esc_html( $email ); ?></strong></td>
                    </tr>
                    <tr>
                        <th scope="row">Backend API Location</th>
                        <td><code><?php echo esc_url( $backend_url ); ?></code></td>
                    </tr>
                    <tr>
                        <th scope="row">Authentication Bearer</th>
                        <td><code style="background:#f6f7f7; color: #2c3338;">••••••••••••••••••••••••••••••••••••••••</code></td>
                    </tr>
                </table>

                <div style="margin-top:20px; display: flex; gap: 10px;">
                    <form method="post" action="" style="display:inline;">
                        <?php wp_nonce_field( 'newsblogify_admin_nonce_action', 'newsblogify_admin_nonce' ); ?>
                        <input type="hidden" name="newsblogify_action" value="refresh_token" />
                        <button type="submit" class="button button-secondary">Refresh OAuth Token</button>
                    </form>

                    <form method="post" action="" style="display:inline;" onsubmit="return confirm('Disconnect website and remove local configuration?');">
                        <?php wp_nonce_field( 'newsblogify_admin_nonce_action', 'newsblogify_admin_nonce' ); ?>
                        <input type="hidden" name="newsblogify_action" value="disconnect" />
                        <button type="submit" class="button button-link" style="color:#d11a2a;">Disconnect Website</button>
                    </form>
                </div>
            </div>
        </div>

        <!-- TAB CONTENT: Publishing -->
        <div id="tab-publishing" class="newsblogify-tab-content">
            <div class="newsblogify-card">
                <h2><span class="dashicons dashicons-admin-post"></span> Post Publishing Settings</h2>
                <table class="form-table">
                    <tr>
                        <th scope="row">Publishing Mode</th>
                        <td>
                            <label>
                                <span class="newsblogify-badge-active" style="background:#e7f4e9; color:#107c10;">REST Enabled</span>
                            </label>
                            <p class="description">Standard WordPress REST endpoints (`/wp-json/wp/v2/posts`) receive draft payloads directly.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Default Status</th>
                        <td>
                            <select disabled>
                                <option selected>Draft</option>
                                <option>Published</option>
                            </select>
                            <p class="description">For safety and SEO checking, all incoming AI articles are originally generated as drafts.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Category Mapping</th>
                        <td>
                            <span class="newsblogify-badge-active" style="background:#f0f0f1; border: 1px solid #ccd0d4; color:#2c3338;">Dynamic Mapping</span>
                            <p class="description">Incoming posts map automatically to matching categories based on AI-selected topic categories.</p>
                        </td>
                    </tr>
                </table>
            </div>
        </div>

        <!-- TAB CONTENT: Sync -->
        <div id="tab-sync" class="newsblogify-tab-content">
            <div class="newsblogify-card">
                <h2><span class="dashicons dashicons-update-alt"></span> Synchronization Queue Settings</h2>
                <table class="form-table">
                    <tr>
                        <th scope="row">WordPress Cron Status</th>
                        <td><span class="newsblogify-badge-active">Online</span></td>
                    </tr>
                    <tr>
                        <th scope="row">Cron Interval</th>
                        <td>Heartbeat: <code>Hourly</code> | Settings Pull: <code>Twice Daily</code></td>
                    </tr>
                    <tr>
                        <th scope="row">Last Heartbeat Execution</th>
                        <td><code><?php echo esc_html( $last_sync ); ?></code></td>
                    </tr>
                </table>
            </div>
        </div>

        <!-- TAB CONTENT: Logs -->
        <div id="tab-logs" class="newsblogify-tab-content">
            <div class="newsblogify-card">
                <h2>
                    <span class="dashicons dashicons-media-text"></span> Diagnostic Activity Log
                    <form method="post" action="" style="display:inline; margin-left: auto;" onsubmit="return confirm('Clear activity log?');">
                        <?php wp_nonce_field( 'newsblogify_admin_nonce_action', 'newsblogify_admin_nonce' ); ?>
                        <input type="hidden" name="newsblogify_action" value="clear_logs" />
                        <button type="submit" class="button button-link" style="color:#d11a2a; font-size:12px;">Clear Log History</button>
                    </form>
                </h2>
                <textarea class="newsblogify-log-textarea" readonly><?php echo esc_textarea( Logger::get_instance()->get_logs( 200 ) ); ?></textarea>
            </div>
        </div>

        <!-- TAB CONTENT: Advanced -->
        <div id="tab-advanced" class="newsblogify-tab-content">
            <form method="post" action="">
                <?php wp_nonce_field( 'newsblogify_admin_nonce_action', 'newsblogify_admin_nonce' ); ?>
                <input type="hidden" name="newsblogify_action" value="save_advanced" />

                <div class="newsblogify-card">
                    <h2><span class="dashicons dashicons-admin-tools"></span> Advanced Settings</h2>
                    <table class="form-table">
                        <tr>
                            <th scope="row">Debug Logging</th>
                            <td>
                                <label for="debug_mode">
                                    <input type="checkbox" name="debug_mode" id="debug_mode" value="1" <?php checked( $debug_mode, '1' ); ?> />
                                    Enable verbose debug logging
                                </label>
                                <p class="description">Write outbound API details and payload responses into the activity logs.</p>
                            </td>
                        </tr>
                    </table>
                    <button type="submit" class="button button-primary">Save Settings</button>
                </div>
            </form>
        </div>
        <?php
    }
}
